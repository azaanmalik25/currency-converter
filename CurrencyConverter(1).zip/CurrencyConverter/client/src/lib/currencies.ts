import type { Currency } from "@shared/schema";

export const currencies: Currency[] = [
  { code: "USD", name: "US Dollar", rate: 1.0 },
  { code: "EUR", name: "Euro", rate: 0.92 },
  { code: "GBP", name: "British Pound", rate: 0.79 },
  { code: "JPY", name: "Japanese Yen", rate: 148.28 },
  { code: "AUD", name: "Australian Dollar", rate: 1.53 },
  { code: "CAD", name: "Canadian Dollar", rate: 1.35 },
  { code: "CHF", name: "Swiss Franc", rate: 0.87 },
  { code: "CNY", name: "Chinese Yuan", rate: 7.19 },
  { code: "INR", name: "Indian Rupee", rate: 83.12 },
  { code: "PKR", name: "Pakistani Rupee", rate: 278.5 },
  { code: "NZD", name: "New Zealand Dollar", rate: 1.65 }
];

export function convert(amount: number, fromCurrency: string, toCurrency: string): number {
  const from = currencies.find(c => c.code === fromCurrency);
  const to = currencies.find(c => c.code === toCurrency);

  if (!from || !to) {
    throw new Error("Invalid currency code");
  }

  // Convert to USD first (base currency), then to target currency
  const usdAmount = amount / from.rate;
  return usdAmount * to.rate;
}