import { z } from "zod";

export const currencySchema = z.object({
  code: z.string().length(3),
  name: z.string(),
  rate: z.number().positive(),
});

export type Currency = z.infer<typeof currencySchema>;

export const convertSchema = z.object({
  amount: z.number().positive(),
  from: z.string().length(3),
  to: z.string().length(3),
});

export type ConvertRequest = z.infer<typeof convertSchema>;
